function validateForm() {
  let a = document.forms["form1"]["n_usu"].value;
  if (a == "") {
    alert("Por favor, ingrese su nombre");
    document.form1.n_usu.focus()
    return false;
  }

  let b = document.forms["form1"]["a_usu"].value;
  if (b == "") {
    alert("Por favor, ingrese su apellido");
    document.form1.a_usu.focus()
    return false;
  }

  let c = document.forms["form1"]["dir_usu"].value;
  if (c == "") {
    alert("Por favor, ingrese su dirección");
    document.form1.dir_usu.focus()
    return false;
  }

  let d = document.forms["form1"]["tel_usu"].value;
  if (d == "") {
    alert("Por favor, ingrese su teléfono");
    document.form1.tel_usu.focus()
    return false;
  }

  let e = document.forms["form1"]["e_usu"].value;
  if (e == "") {
    alert("Por favor, ingrese su correo electrónico");
    document.form1.e_usu.focus()
    return false;
  }

  let f = document.forms["form1"]["ciu_usu"].value;
  if (f == "") {
    alert("Por favor, ingrese su ciudad de ubicación");
    document.form1.ciu_usu.focus()
    return false;
  }

  let g = document.forms["form1"]["nick_usu"].value;
  if (g == "") {
    alert("Por favor, ingrese su Usuario");
    document.form1.nick_usu.focus()
    return false;
  }

  let h = document.forms["form1"]["pass_usu"].value;
  if (h == "") {
    alert("Por favor, ingrese su contraseña");
    document.form1.pass_usu.focus()
    return false;
  }

}

function validarForm() {
  let a = document.forms["form1"]["bproducto"].value;
  if (a == "") {
    alert("Por favor, ingrese el nombre del producto");
    document.form1.bproducto.focus()
    return false;
  }
}

function validarCompra() {
  let a =  document.forms["form1"]["Producto"].value;
  if (a == "") {
    alert("Debe seleccionar un producto");
    document.form1.Producto.focus()
    return false;
  }

  let b = document.forms["form1"]["Cant"].value;
  if (b == "" || b <= 0) {
    alert("Por favor, ingrese una cantidad a comprar");
    document.form1.Cant.focus()
    return false;
  }
}

function validarLogin() {
  let a =  document.forms["form1"]["uemail"].value;
  if (a == "") {
    alert("Por favor, ingrese su usuario");
    document.form1.uemail.focus()
    return false;
  }

  let b = document.forms["form1"]["upswd"].value;
  if (b == "") {
    alert("Por favor, ingrese su contraseña");
    document.form1.upswd.focus()
    return false;
  }
}

